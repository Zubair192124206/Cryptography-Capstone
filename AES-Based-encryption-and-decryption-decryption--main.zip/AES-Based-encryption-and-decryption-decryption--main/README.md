# AES-Based-encryption-and-decryption-decryption-
AES Encryptor Suite is a client-side web toolset for encrypting/decrypting images, files, and text using AES-GCM with password-based key derivation (PBKDF2). Secure, easy-to-use, with no server needed—keep your data safe directly in the browser.
